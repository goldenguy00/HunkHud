# Changelog

`1.1.2`
- Added Acolyte support

`1.1.1`
- Grah

`1.1.0`
- Updated for DLC4

`1.0.5`
- Fixed Hunk compat

`1.0.4`
- Hunk compat
- Fixed icon placements

`1.0.3`
- Fixed for latest RiskUI version

`1.0.2`
- No idea tbh

`1.0.1`

- Fixed some misalignments/minor layout errors
- Fixed LG incompat

`1.0.0`

- AC update

`0.2.5`

- Dante compat
- Money elements now show when near interactables
- Skill visibility is a bit more accurate, only applies for skills with cooldowns
- ChildLocator updated
- Soon...

`0.2.3`

- Moved hp bar more to the corner
- Ally hp bars get shown when pressing tab
- Barrier decay no longer makes elements visible
- Added fade out
- Added low hp display
- Money text movement paths updated
- Lots of very secret backend work shhhhhh

`0.2.1`

- Fixed band display not appearing
- Try to release an update without regression challenge: IMPOSSIBLE

`0.2.0`

- Ally cards get sorted better
- Lunar ruin display
- Frozen display
- More HP bar accuracy fixes

`0.1.8`

- didnt happen

`0.1.7`

- Absolutely BANGER Readme update from Smxrez

`0.1.6`

- Ally Cards get moved when inactive
- Fixed buff positioning again
- Fixed Delayed Damage mask inaccuracies
- Restored the correct default chatbox positioning
- Force Lee specific chatbox positioning
- More backend staging stuff

`0.1.5`

- Buffs moved down to the correct spot oops

`0.1.4`

- Forces a couple of specific RiskUI positioning options
- Added Dynamic Crosshair
- Fixed Health display using the wrong texture
- More improvements to Echo and Collapse accuracy

`0.1.3`

- Moved band display higher again
- OSP display
- Echo display fixed
- Some backend staging stuff
- Fixed offset inventory display when at the bottom

`0.1.2`

- Works with Hunk and Nemesis now
- Maybe lol

`0.1.1`

- NaN fix

`0.1.0`

- Mod support stuff
- Tiny repositioning of hp bar
- Hp bar fills slower

`0.0.9`

- RiskUI is a dependency now
- Bands now get attached to the healthbar
- Further hp bar accuracy improvements
- Buffs display should stay on screen now

`0.0.8`

- Fixed bands having inconsistent positioning
- Fixed issue with echo damage being always active

`0.0.7`

- Fixed band cooldowns not filling up
- Centered some stuff

`0.0.6`

- Collapse and warped echo display added
- Luminous Shot display fills from the bottom now
- Fixed issue with healthbar displaying an extra bar
- Fixed band display overlapping with healthbar
- Minor adjustments to display movement for all UI elements

`0.0.5`

- Improved accuracy of Healthbar
- Minor adjustments to positioning
- Better support for custom fonts

`0.0.4`

- Item notification added
- Driver support added
- Moved hud setup to earlier in the startup sequence

`0.0.3`

- Updated thunderstore stuff
- Updated band display to support Augmentum and Sandswept

`0.0.2`

- Moved to thunderkit
- Luminous shot display added
- Band tracker added
- Changed custom health bar to be on the left
- Better dynamics

`0.0.1`

- Initial Release