# HunkHud (Beta release)
Overhauls risk of rain 2's UI to be like HUNK's custom hud (HUNK not reqiured).

This is a beta release with config options coming soon (simple enable/disable only for now)

Risk UI is highly recommended.

Report bugs and give feedback on the discord: https://discord.gg/xqp5CQM8Cs
# Preview
### Dynamic hud elements
![](https://i.postimg.cc/nzK7ZfMG/ezgif-13258a2e249c20.gif)
### New item pickup prompt
![](https://i.postimg.cc/VkP7Wmnz/CB402069-BAD1-42-E7-8576-CF9-C5-DEB722-A.png)
### Band cooldown display
![](https://i.postimg.cc/cJsXPhFj/F5-C5-B3-B3-B6-BD-4-E06-AC3-E-7-CC93-AFF6-DEC.png)
### Luminous shot display
![](https://i.postimg.cc/KYJJbTVY/0-B8-CBF20-7-E7-C-43-D6-95-BC-636-E35-BE0790.png)
### Support for Driver
![](https://i.postimg.cc/Z5Pwf2xp/4737-BD48-DB39-424-D-B3-DA-54-F3-CBBBDA16.png)
