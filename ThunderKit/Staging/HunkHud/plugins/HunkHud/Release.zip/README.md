# Hunk Hud - BETA RELEASE
---
## Standalone Hud from HUNK

beta release, config options coming soon (simple enable/disable only for now)

risk UI is highly recommended

---

report bugs to the discord 

https://discord.gg/xqp5CQM8Cs