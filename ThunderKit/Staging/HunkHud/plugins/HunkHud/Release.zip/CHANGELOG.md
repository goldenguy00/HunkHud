`0.0.5`

- Improved accuracy of Healthbar
- Minor adjustments to positioning
- Better support for custom fonts

`0.0.4`

- Item notification added
- Driver support added
- Moved hud setup to earlier in the startup sequence

`0.0.3`

- Updated thunderstore stuff
- Updated band display to support Augmentum and Sandswept

`0.0.2`

- Moved to thunderkit
- Luminous shot display added
- Band tracker added
- Changed custom health bar to be on the left
- Better dynamics

`0.0.1`

- Initial Release